package parser;

public class Schedule {
	private Textbook[] textbooks;
	private Week[] weeks;
	
	public Textbook[] getTextbooks() {
		return textbooks;
	}

	public void setTextbooks(Textbook[] textbooks) {
		this.textbooks = textbooks;
	}

	public Week[] getWeeks() {
		return weeks;
	}

	public void setWeeks(Week[] weeks) {
		this.weeks = weeks;
	}
}
