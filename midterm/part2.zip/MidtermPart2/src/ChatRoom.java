import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

public class ChatRoom {

	private Vector<ServerThread> serverThreads;
	private Game game;
	private int reply;
	public ChatRoom(int port) {
		try {
			reply = 0;
			ServerSocket ss = new ServerSocket(port);
			serverThreads = new Vector<ServerThread>();
			while(true) {
				Socket s = ss.accept(); // blocking
				//System.out.println("Connection from: " + s.getInetAddress());
				ServerThread st = new ServerThread(s, this);
				serverThreads.add(st);
				if(serverThreads.size() == 2) {
					serverThreads.get(0).sendMessage("Player 1 Bet - $");
				}
			}
		} catch (IOException ioe) {
			System.out.println("ioe in ChatRoom constructor: " + ioe.getMessage());
		}
	}
	
	public void next(String message) {
		if(message.matches("[1-9]?\\d") || message.equals("100")) {
			System.out.println("Here");
		    int bet = Integer.parseInt(message);
		    game = new Game(bet);
		    reply = 0;
		    serverThreads.get(1).sendMessage("Player 2 Agree? ");
		}
		else if(message.equals("No")) {
			emit("Thank you for playing war.", serverThreads.get(0));
		}
		else if(message.equals("ReadyYes")) {
			reply++;
			if(reply == 2) {
				next("Yes");
			}
		}
		else if(message.equals("Yes")) {
			Card player1Card = game.drawCard();
			Card player2Card = game.drawCard();
			emit("Player 1 Card - " + player1Card.getRank() + "\n", serverThreads.get(0));
			emit("Player 2 Card - " + player2Card.getRank() + "\n\n", serverThreads.get(0));
			
			if(player1Card.getValue() > player2Card.getValue()) {
				emit("Player 1 wins " + game.bet + "\n", serverThreads.get(0));
				emit("Player 2 loses " + game.bet + "\n", serverThreads.get(0));
				emit("\nThank you for playing war.", serverThreads.get(0));
			}
			else if(player1Card.getValue() < player2Card.getValue()) {
				emit("Player 1 loses " + game.bet + "\n", serverThreads.get(0));
				emit("Player 2 wins " + game.bet + "\n", serverThreads.get(0));
				emit("\nThank you for playing war.", serverThreads.get(0));
			}
			else {
				emit("Ready to continue?", serverThreads.get(0));
			}
		}
	}
	
	public void emit(String message, ServerThread st) {
		if (message != null) {
			System.out.println(message);
			for(ServerThread threads : serverThreads) {
				threads.sendMessage(message);
			}
		}
	}
	
	public static void main(String [] args) {
		ChatRoom cr = new ChatRoom(6789);
	}
}