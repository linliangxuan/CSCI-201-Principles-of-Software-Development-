package Logic;

public class Card {

	private String rank;

	public Card(String rank) {
		this.rank = rank;
	}
	
	public String getRank() {
		return rank;
	}

	public int getValue() {
		if(rank == "2") {
			return 2;
		}
		else if(rank == "3") {
			return 3;
		}
		else if(rank == "4") {
			return 4;
		}
		else if(rank == "5") {
			return 5;
		}
		else if(rank == "6") {
			return 6;
		}
		else if(rank == "7") {
			return 7;
		}
		else if(rank == "8") {
			return 8;
		}
		else if(rank == "9") {
			return 9;
		}
		else if(rank == "10") {
			return 10;
		}
		else if(rank == "J") {
			return 11;
		}
		else if(rank == "Q") {
			return 12;
		}
		else if(rank == "K") {
			return 13;
		}
		else {
			return 14;
		}
	}




}
