package Logic;
import java.util.Collections;
import java.util.Scanner;
import java.util.Vector;

public class Game {

	public String player;
	public Vector<Card> deck;
	public int bet;
	
	public Game(int bet) {
		this.bet = bet;
		deck = new Vector<Card>();
		
		Vector<String> temp = new Vector<String>();
		temp.add("2");temp.add("3");temp.add("4");temp.add("5");
		temp.add("6");temp.add("7");temp.add("8");temp.add("9");
		temp.add("10");temp.add("J");temp.add("Q");temp.add("K");temp.add("A");
		
		for(int i = 0; i < temp.size(); i++) {
			Card card = new Card(temp.get(i));
			deck.add(card);
		}
	}
	
	public Card drawCard() {
		Collections.shuffle(deck);
		return deck.get(0);
	}
	/*
	public static void main(String [] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.print("Player 1 Bet - $");
		int bet = Integer.parseInt(scan.nextLine());
		System.out.print("Player 2 Agree? ");
		String player2Agree = scan.nextLine();
		if(player2Agree.equals("Yes")) {
			System.out.print("\n");
			Game game = new Game(bet);
			while(true) {
				Card player1Card = game.drawCard();
				Card player2Card = game.drawCard();
				System.out.println("Player 1 Card - " + player1Card.getRank());
				System.out.println("Player 2 Card - " + player2Card.getRank());
				System.out.print("\n");
				
				if(player1Card.getValue() > player2Card.getValue()) {
					System.out.println("Player 1 wins " + game.bet);
					System.out.println("Player 2 loses " + game.bet);
					
					System.out.print("\n");
					
					System.out.println("Thank you for playing war.");
					break;
				}
				else if(player1Card.getValue() < player2Card.getValue()) {
					System.out.println("Player 1 loses " + game.bet);
					System.out.println("Player 2 wins " + game.bet);
					
					System.out.print("\n");
					
					System.out.println("Thank you for playing war.");
					break;
				}
				else {
					System.out.print("Ready to continue? ");
					String reply = scan.nextLine();
					if(reply.equals("No")) {
						System.out.print("\n");
						
						System.out.println("Thank you for playing war.");
						
						break;
					}
				}
			}
		}
		else {
			System.out.print("\n");
			System.out.println("Thank you for playing war.");
		}
		
	}
	*/

}
