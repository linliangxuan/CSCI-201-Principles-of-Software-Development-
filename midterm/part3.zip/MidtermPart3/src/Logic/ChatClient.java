package Logic;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class ChatClient extends Thread {

	private BufferedReader br;
	private PrintWriter pw;
	private boolean ready;
	public String received;
	public ChatClient(String hostname, int port) {
		try {
			ready = false;
			Socket s = new Socket(hostname, port);
			br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			pw = new PrintWriter(s.getOutputStream());
			this.start();
			Scanner scan = new Scanner(System.in);
			while(true) {
				String line = scan.nextLine();
				if(ready == true && line.equals("Yes")) {
					pw.println("ReadyYes");
					pw.flush();
				}
				else {
					pw.println(line);
					pw.flush();
				}
			}
			
		} catch (IOException ioe) {
			System.out.println("ioe in ChatClient constructor: " + ioe.getMessage());
		}
	}
	public void run() {
		try {
			while(true) {
				String line = br.readLine();
				if(line.equals("Ready to continue?")) {
					ready = true;
				}
				received = line;
				System.out.println(line);
			}
		} catch (IOException ioe) {
			System.out.println("ioe in ChatClient.run(): " + ioe.getMessage());
		}
	}
	public static void main(String [] args) {
		ChatClient cc = new ChatClient("localhost", 6789);
	}
}