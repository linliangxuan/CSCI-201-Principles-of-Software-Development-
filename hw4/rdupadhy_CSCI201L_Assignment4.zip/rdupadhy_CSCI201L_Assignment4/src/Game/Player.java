package Game;
import java.util.Vector;

import Network.GameServerThread;

public class Player {

	private String username;
	private GameServerThread gameServerThread;
	private Vector<Card> cards;
	private int chips;
	private int currentBet;
	private boolean bust;
	private boolean blackjack;

	public Player(String username) {
		this.username = username;
		cards = new Vector<Card>();
		chips = 500;
		currentBet = 0;
		bust = false;
		blackjack = false;
	}
	
	public int maximumValueUnder21() {
		int maxValue = 0;
		for(int i = 0 ; i < cards.size(); i++) {
			Card card = cards.get(i);
			if(card.getRank() == Card.Rank.ACE) {
				maxValue += 11;
			}
			else {
				maxValue += card.value();
			}
		}
		while(maxValue > 21) {
			maxValue -= 10;
		}
		return maxValue;
	}
	
	public int numAces() {
		int numAces = 0;
		for(int i = 0 ; i < cards.size(); i++) {
			Card card = cards.get(i);
			if(card.getRank() == Card.Rank.ACE) {
				numAces++;
			}
		}
		return numAces;
	}
	
//	public int aceValue() {
//		return playerCardsValue() + 10;
//	}
	
	//Updates round. Player returns their cards to the dealer and restores the value of currentBet to 0
	public void updateRound() {
		cards = new Vector<Card>();
		currentBet = 0;
	}
	
	//Adds a vector of cards to the player's hand
	public void addCards(Vector<Card> cards) {
		this.cards.addAll(cards);
	}
	
	//Increments or decrements player chips at the end of the round
	public void changeChips(int change) {
		chips += change;
	}
	
	//Returns the sum of the values of cards the player holds
	public int playerCardsValue() {
		int playerCardsValue = 0;
		for(int i = 0; i < cards.size(); i++) {
			Card card = cards.get(i);
			playerCardsValue += card.value();
		}
		return playerCardsValue;
	}
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public GameServerThread getGameServerThread() {
		return gameServerThread;
	}

	public void setGameServerThread(GameServerThread gameServerThread) {
		this.gameServerThread = gameServerThread;
	}

	public int getChips() {
		return chips;
	}

	public void setChips(int chips) {
		this.chips = chips;
	}

	public int getCurrentBet() {
		return currentBet;
	}

	public void setCurrentBet(int currentBet) {
		this.currentBet = currentBet;
	}

	public Vector<Card> getCards() {
		return cards;
	}

	public void setCards(Vector<Card> cards) {
		this.cards = cards;
	}

	public boolean isBust() {
		return bust;
	}

	public void setBust(boolean bust) {
		this.bust = bust;
	}

	public boolean isBlackjack() {
		return blackjack;
	}

	public void setBlackjack(boolean blackjack) {
		this.blackjack = blackjack;
	}
	
	
}
