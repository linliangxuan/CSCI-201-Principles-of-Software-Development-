package Game;
import java.util.Vector;

public class Game {
	
	private String gamename;
	private int numPlayers;
	private Vector<Player> players;
	private int currentPlayerIndex;
	private Deck deck;
	private Vector<Card> dealerCards;
	private int round;
	
	public Game(String gamename) {
		this.gamename = gamename;
		players = new Vector<Player>();
		currentPlayerIndex = 0;
		numPlayers = 0;
		deck = new Deck();
		dealerCards = new Vector<Card>();
		round = 1;
	}
	
	public Game(String gamename, int numPlayers) {
		this.gamename = gamename;
		this.numPlayers = numPlayers;
		players = new Vector<Player>();
		numPlayers = 0;
		deck = new Deck();
		currentPlayerIndex = 0;
		dealerCards = new Vector<Card>();
		round = 1;
	}
	
	//Updates round. Increments value of round and collects cards back from all players in the game
	public void updateRound() {
		round++;
		deck = new Deck();
		dealerCards = new Vector<Card>();
		for(int i = 0; i < players.size(); i++) {
			Player player = players.get(i);
			player.updateRound();
		}
	}
	
	public int dealerMaximumValueUnder21() {
		int maxValue = 0;
		for(int i = 0 ; i < dealerCards.size(); i++) {
			Card card = dealerCards.get(i);
			if(card.getRank() == Card.Rank.ACE) {
				maxValue += 11;
			}
			else {
				maxValue += card.value();
			}
		}
		while(maxValue > 21) {
			maxValue -= 10;
		}
		return maxValue;
	}
	
	public int dealerNumAces() {
		int numAces = 0;
		for(int i = 0 ; i < dealerCards.size(); i++) {
			Card card = dealerCards.get(i);
			if(card.getRank() == Card.Rank.ACE) {
				numAces++;
			}
		}
		return numAces;
	}
	
//	public int dealerAceValue() {
//		return dealerCardsValue() + 10;
//	}
	
	//Returns the sum of the values of cards the dealer holds
	public int dealerCardsValue() {
		int dealerCardsValue = 0;
		for(int i = 0; i < dealerCards.size(); i++) {
			Card card = dealerCards.get(i);
			dealerCardsValue += card.value();
		}
		return dealerCardsValue;
	}
	
	//Adds a vector of cards to the dealer's hand
	public void addDealerCards(Vector<Card> cards) {
		dealerCards.addAll(cards);
	}
	
	//Shuffles the deck
	public void shuffleDeck() {
		deck.shuffle();
	}
	
	public String getGamename() {
		return gamename;
	}

	public void setGamename(String gamename) {
		this.gamename = gamename;
	}
	
	public int getNumPlayers() {
		return numPlayers;
	}

	public void setNumPlayers(int numPlayers) {
		this.numPlayers = numPlayers;
	}
	
	public Vector<Player> getPlayers() {
		return players;
	}
	
	public void setPlayers(Vector<Player> players) {
		this.players = players;
	}
	
	public void addPlayer(Player player) {
		players.add(player);
	}
	
	//Checks whether player with already username exists in the game. Returns true if it does, false otherwise.
	public boolean usernameExists(String username) {
		for(int i = 0; i < players.size(); i++) {
			Player player = players.get(i);
			if(player.getUsername().equals(username)) {
				return true;
			}
		}
		return false;
	}

	public int getCurrentPlayerIndex() {
		return currentPlayerIndex;
	}

	public void setCurrentPlayerIndex(int currentPlayerIndex) {
		this.currentPlayerIndex = currentPlayerIndex;
	}

	public Deck getDeck() {
		return deck;
	}

	public void setDeck(Deck deck) {
		this.deck = deck;
	}

	public Vector<Card> getDealerCards() {
		return dealerCards;
	}

	public void setDealerCards(Vector<Card> dealerCards) {
		this.dealerCards = dealerCards;
	}

	public int getRound() {
		return round;
	}

	public void setRound(int round) {
		this.round = round;
	}
	
}
