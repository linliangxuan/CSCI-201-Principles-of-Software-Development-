package Game;

public class Card {
	
	private Suit suit;
	private Rank rank;
	//Type safe enumeration type representing the suit of a card
	public enum Suit {
		SPADES,
		HEARTS,
		DIAMONDS,
		CLUBS
	}
	//Type safe enumeration type representing the rank of a card
	public enum Rank {
		ACE,
		TWO,
	    THREE,
	    FOUR,
	    FIVE,
	    SIX,
	    SEVEN,
	    EIGHT,
	    NINE,
	    TEN,
	    JACK,
	    QUEEN,
	    KING
	}
	
	public Card(Suit suit, Rank rank) {
		this.suit = suit;
		this.rank = rank;
	}
	
	//Prints card in the format: RANK of SUIT
	public String printCard() {
		String returnString = rank + " of " + suit;
		return returnString;
	}

	public Suit getSuit() {
		return suit;
	}

	public void setSuit(Suit suit) {
		this.suit = suit;
	}

	public Rank getRank() {
		return rank;
	}

	public void setRank(Rank rank) {
		this.rank = rank;
	}
	
	//Return value of card. Returns 1 for ACE
	public int value() {
		if(rank.ordinal() <= 9) {
			return rank.ordinal() + 1;
		}
		return 10;
	}
	
}
