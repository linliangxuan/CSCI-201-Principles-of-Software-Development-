package Utility;

import java.util.Vector;

import Game.Card;

public class VectorUtility {

	public static boolean containsGreaterThanOrEqualTo(Vector<Integer> vector, int value) {
		for(int i = 0; i < vector.size(); i++) {
			if(vector.get(i) >= value) {
				return true;
			}
		}
		return false;
	}
	
	public static int maximumValueUnder21(Vector<Card> cards) {
		int maxValue = 0;
		for(int i = 0 ; i < cards.size(); i++) {
			Card card = cards.get(i);
			if(card.getRank() == Card.Rank.ACE) {
				maxValue += 11;
			}
			else {
				maxValue += card.value();
			}
		}
		while(maxValue > 21) {
			maxValue -= 10;
		}
		return maxValue;
	}
	
}
