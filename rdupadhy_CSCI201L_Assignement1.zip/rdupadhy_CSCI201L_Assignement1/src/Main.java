import java.io.FileNotFoundException;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.stream.JsonReader;


public class Main {

	public Education education;
	public School school;
	public Department department;
	public Course course;

	public static void main(String[] args) {

		Gson gson = new Gson();
		JsonReader jsonReader = null;
		Scanner scanner = new Scanner(System.in);
		boolean invalidJson = true; 
		
		while (jsonReader == null || invalidJson == true) {

			try {
				
				System.out.print("What is the name of the input file? ");
				String fileName = scanner.next();
				jsonReader = new JsonReader(new FileReader(fileName));
				Education education = gson.fromJson(jsonReader, Education.class);
				Main main = new Main();
				
				boolean result = main.invalidJson(education);
				if(!result) {
					System.out.println("That file is not a well-formed JSON file." + "\n ");
				}
				else {
					invalidJson = false;
					main.mainMenu(education);
				}
				
			} catch (FileNotFoundException e) {
				
				System.out.println("That file could not be found." + "\n ");
				
			} catch(JsonSyntaxException e) {
				
				System.out.println("That file is not a well-formed JSON file." + "\n ");
				
			}
			

		}
		scanner.close();
		
	}
	
	public boolean invalidJson(Education education) {
		School[] testSchools = education.getSchools();
		if(testSchools == null || testSchools.length == 0) {
			return false;
		}
		else {
			for(int i = 0; i < testSchools.length; i++) {
				if(testSchools[i].getName() == null) {
					return false;
				}
				Department[] testDepartments = testSchools[i].getDepartments();
				if(testDepartments == null || testDepartments.length == 0) {
					return false;
				}
				else {
					for(int j = 0; j < testDepartments.length; j++) {
						if(testDepartments[j].getLongName() == null ||
						testDepartments[j].getPrefix() == null) {
							return false;
						}
						Course[] testCourses = testDepartments[j].getCourses();
						if(testCourses == null || testCourses.length == 0) {
							return false;
						}
						else {
							for(int k = 0; k < testCourses.length; k++) {
								if(testCourses[k].getNumber() == null ||
							       testCourses[k].getTerm() == null ||
								   testCourses[k].getYear() == null) {
									return false;
								}
								StaffMember[] testStaffMembers = testCourses[k].getStaffMembers();
								Meeting[] testMeetings = testCourses[k].getMeetings();
								if(testStaffMembers == null || testStaffMembers.length == 0) {
									return false;
								}
								else {
									for(int l = 0; l < testStaffMembers.length; l++) {
										if(testStaffMembers[l].getType() == null ||
										   testStaffMembers[l].getId() == null ||
										   testStaffMembers[l].getName() == null) {
											return false;
										}
										else if(testStaffMembers[l].getName().getFname() == null
										   || testStaffMembers[l].getName().getFname() == null) {
											return false;
										}
									}
								}
								if(testMeetings == null || testMeetings.length == 0) {
									return false;
								}
								else {
									for(int l = 0; l < testMeetings.length; l++) {
										if(testMeetings[l].getType() == null ||
										   testMeetings[l].getSection() == null) {
											return false;
										}
									}
								}
							}
						}
					}
				}
			}
		}
		
		return true;
 		
	}

	public void mainMenu(Education education) {

		this.education = education;
		Scanner scanner = new Scanner(System.in);
		int option = 0;
		
		while (true) {
			System.out.println("\n\t1) Display Schools\n\t2) Exit");
			System.out.print("What would you like to do? ");
			
			if(scanner.hasNextInt()) {
				option = scanner.nextInt();
			}
			
			if (option == 1) {
				schoolsMenu();
				break;
			} else if (option == 2) {
				exitOption();
				break;
			} else {
				System.out.println("\nThat is not a valid option.");
			}
		}
		
		scanner.close();

	}
	
	public void schoolsMenu() {

		Scanner scanner = new Scanner(System.in);
		int option = 0;
		
		while (true) {
			System.out.println("\nSchools");
			School[] schools = education.getSchools();
			int length = schools.length;
			for (int i = 0; i < length; i++) {
				System.out.println("\t" + (i + 1) + ") " + schools[i].getName());
			}
			System.out.println("\t" + (length + 1) + ") Go to main menu");
			System.out.println("\t" + (length + 2) + ") Exit");
			System.out.print("What would you like to do? ");
			
			if(scanner.hasNextInt()) {
				option = scanner.nextInt();
			}
			
			if (option >= 1 && option <= length) {
				school = schools[option - 1];
				departmentsMenu();
				break;
			} else if (option == length + 1) {
				mainMenu(education);
				break;
			} else if (option == length + 2) {
				exitOption();
				break;
			} else {
				System.out.println("\nThat is not a valid option.");
			}
		}
		
		scanner.close();
		
	}

	public void departmentsMenu() {

		Scanner scanner = new Scanner(System.in);
		int option = 0;
		
		while (true) {
			System.out.println("\nDepartments");
			Department[] departments = school.getDepartments();
			int length = departments.length;
			for (int i = 0; i < length; i++) {
				System.out.println("\t" + (i + 1) + ") " + departments[i].getLongName() + " ("
						+ departments[i].getPrefix() + ")");
			}
			System.out.println("\t" + (length + 1) + ") Go to Schools menu");
			System.out.println("\t" + (length + 2) + ") Exit");
			System.out.print("What would you like to do? ");
			
			if(scanner.hasNextInt()) {
				option = scanner.nextInt();
			}
			
			if (option >= 1 && option <= length) {
				department = departments[option - 1];
				coursesMenu();
				break;
			} else if (option == length + 1) {
				schoolsMenu();
				break;
			} else if (option == length + 2) {
				exitOption();
				break;
			} else {
				System.out.println("\nThat is not a valid option.");
			}
		}

		scanner.close();
		
	}

	public void coursesMenu() {
		
		Scanner scanner = new Scanner(System.in);
		int option = 0;

		while (true) {
			System.out.println("\n" + department.getPrefix() + " Courses");
			Course[] courses = department.getCourses();
			int length = courses.length;
			for (int i = 0; i < length; i++) {
				System.out.println("\t" + (i + 1) + ") " + department.getPrefix() + " " + courses[i].getNumber() + " "
						+ courses[i].getTerm() + " " + courses[i].getYear());
			}
			System.out.println("\t" + (length + 1) + ") Go to Departments menu");
			System.out.println("\t" + (length + 2) + ") Exit");
			System.out.print("What would you like to do? ");
			
			if(scanner.hasNextInt()) {
				option = scanner.nextInt();
			}
			
			if (option >= 1 && option <= length) {
				course = courses[option - 1];
				courseGeneralMenu();
				break;
			} else if (option == length + 1) {
				departmentsMenu();
				break;
			} else if (option == length + 2) {
				exitOption();
				break;
			} else {
				System.out.println("\nThat is not a valid option.");
			}
		}

		scanner.close();
		
	}

	public void courseGeneralMenu() {

		Scanner scanner = new Scanner(System.in);
		int option = 0;
		
		while (true) {
			System.out.println("\n" + department.getPrefix() + " " + course.getNumber() + " " + course.getTerm() + " "
					+ course.getYear());
			System.out.println("\t1) View course staff\n\t2) View meeting information");
			System.out.println("\t3) Go to " + department.getPrefix() + " Courses menu");
			System.out.println("\t4) Exit");
			System.out.print("What would you like to do? ");
			
			if(scanner.hasNextInt()) {
				option = scanner.nextInt();
			}
			
			if (option == 1) {
				courseStaffMenu();
				break;
			} else if (option == 2) {
				courseMeetingInformationMenu();
				break;
			} else if (option == 3) {
				coursesMenu();
				break;
			} else if (option == 4) {
				exitOption();
				break;
			} else {
				System.out.println("\nThat is not a valid option.");
			}
		}
		
		scanner.close();
		
	}

	public void courseStaffMenu() {
		
		Scanner scanner = new Scanner(System.in);
		int option = 0;
		
		while(true) {
			System.out.println("\n" + department.getPrefix() + " " + course.getNumber() + " " + course.getTerm() + " "
					+ course.getYear());
			System.out.println("Course Staff");
			System.out.println("\t1) View Instructors\n\t2) View TAs\n"
					          + "\t3) View CPs\n\t4) View Graders");
			System.out.println("\t5) Go to " + department.getPrefix() + " " + course.getNumber() + " "
					+ course.getTerm() + " " + course.getYear() + " menu");
			System.out.println("\t6) Exit");
			System.out.print("What would you like to do? ");
			
			if(scanner.hasNextInt()) {
				option = scanner.nextInt();
			}
			
			if (option == 1) {
				courseStaffMenuOption("Instructor");
			} else if (option == 2) {
				courseStaffMenuOption("TA");
			} else if (option == 3) {
				courseStaffMenuOption("CP");
			} else if (option == 4) {
				courseStaffMenuOption("Grader");
			} else if (option == 5) {
				courseGeneralMenu();
				break;
			} else if (option == 6) {
				exitOption();
				break;
			} else {
				System.out.println("\nThat is not a valid option.");
			}
		}
		
		scanner.close();
		
	}

	public void courseMeetingInformationMenu() {

		Scanner scanner = new Scanner(System.in);
		int option = 0;
		
		while (true) {
			System.out.println("\n" + department.getPrefix() + " " + course.getNumber() + " " + course.getTerm() + " "
					+ course.getYear());
			System.out.println("Meeting Information");
			System.out.println("\t1) Lecture\n\t2) Lab\n\t3) Quiz");
			System.out.println("\t4) Go to " + department.getPrefix() + " " + course.getNumber() + " "
					+ course.getTerm() + " " + course.getYear() + " menu");
			System.out.println("\t5) Exit");
			System.out.print("What would you like to do? ");
			
			if(scanner.hasNextInt()) {
				option = scanner.nextInt();
			}
			
			if (option == 1) {
				courseMeetingInformationMenuOption("Lecture");
			} else if (option == 2) {
				courseMeetingInformationMenuOption("Lab");
			} else if (option == 3) {
				courseMeetingInformationMenuOption("Quiz");
			} else if (option == 4) {
				courseGeneralMenu();
				break;
			} else if (option == 5) {
				exitOption();
				break;
			} else {
				System.out.println("\nThat is not a valid option.");
			}
		}
		
		scanner.close();
		
	}

	public void exitOption() {

		System.out.println("\nThank you for using my program!");

	}
	
	public void courseStaffMenuOption(String type) {
		
		StaffMember[] staffMembers = course.getStaffMembers();
		ArrayList<StaffMember> staffMembersType = new ArrayList<StaffMember>();
		for(int i = 0; i < staffMembers.length; i++) {
			if(staffMembers[i].getType().equals(type.toLowerCase())) {
				staffMembersType.add(staffMembers[i]);
			}
		}
		System.out.println("\n" + department.getPrefix() + " " + course.getNumber() + " " + course.getTerm() + " "
				+ course.getYear());
		if(staffMembersType.size() == 0) {
			System.out.println(type + ": Not found");
			return;
		} 
		else {
			if(staffMembersType.size() == 1) {
				System.out.println(type);
			}
			else {
				System.out.println(type + "s");
			}
			
		}
		for(int i = 0; i < staffMembersType.size(); i++) {
			StaffMember staffMember = staffMembersType.get(i);
			OfficeHour[] officeHours = staffMember.getOfficeHours();
			System.out.println("Name: " + staffMember.getName().getFname()
					           + " " + staffMember.getName().getLname());
			if(staffMember.getEmail() == null) {
				System.out.println("Email: Not available");
			}
			else {
				System.out.println("Email: " + staffMember.getEmail());
			}
			if(staffMember.getImage() == null) {
				System.out.println("Image: Not available");
			}
			else {
				System.out.println("Image: " + staffMember.getImage());
			}
			if(staffMember.getPhone() == null) {
				System.out.println("Phone: Not available");
			}
			else {
				System.out.println("Phone: " + staffMember.getPhone());
			}
			if(staffMember.getOffice() == null) {
				System.out.println("Office: Not available");
			}
			else {
				System.out.println("Office: " + staffMember.getOffice());
			}
			if(staffMember.getOfficeHours() == null || staffMember.getOfficeHours().length == 0) {
				System.out.println("Office Hours: Not available");
				return;
			}
			else {
				System.out.print("Office Hours: ");
			}
			boolean firstFound = false;
			for(int j = 0; j < officeHours.length; j++) {
				OfficeHour officeHour = officeHours[j];
				if(j == 0) {
					if(officeHour.getDay() != null) {
						firstFound = true;
						if(officeHour.getTime() != null) {
							String start = "";
							String end = "";
							if(officeHour.getTime().getStart() != null) {
								start = officeHour.getTime().getStart();
							}
							if(officeHour.getTime().getEnd() != null) {
								end = officeHour.getTime().getEnd();
							}
							System.out.print(officeHour.getDay() + " " + start + "-" 
									+ end);
						}
						else {
							System.out.print(officeHour.getDay());
						}
					}
				}
				else {
					if(officeHour.getDay() != null) {
						if(officeHour.getTime() != null) {
							String start = "";
							String end = "";
							if(officeHour.getTime().getStart() != null) {
								start = officeHour.getTime().getStart();
							}
							if(officeHour.getTime().getEnd() != null) {
								end = officeHour.getTime().getEnd();
							}
							
							if(firstFound == false) {
								firstFound = true;
								System.out.print(officeHour.getDay() + " " + start + "-" 
										+ end);
							}
							else {
								System.out.print(", " + officeHour.getDay() + " " + start + "-" 
										+ end);
							}
							
						}
						else {
							
							if(firstFound == false) {
								firstFound = true;
								System.out.print(officeHour.getDay());
							}
							else {
								System.out.print(", " + officeHour.getDay());
							}
							
						}
					}
				}
			}
			if(i == staffMembersType.size() - 1){
				System.out.print("\n");
			}
			else {
				System.out.print("\n\n");
			}
			
		}
	}
	
	public void courseMeetingInformationMenuOption(String type) {
		
		Meeting[] meetings = course.getMeetings();
		ArrayList<Meeting> meetingType = new ArrayList<Meeting>();
		for(int i = 0; i < meetings.length; i++) {
			if(meetings[i].getType().equals(type.toLowerCase())) {
				meetingType.add(meetings[i]);
			}
		}
		System.out.println("\n" + department.getPrefix() + " " + course.getNumber() + " " + course.getTerm() + " "
				+ course.getYear());
		if(meetingType.size() == 0) {
			System.out.println(type + " Meeting Information: Not found");
			return;
		} 
		else {
			System.out.println(type + " Meeting Information");
		}
		for(int i = 0; i < meetingType.size(); i++) {
			Meeting meeting = meetingType.get(i);
			MeetingPeriod[] meetingPeriods = meeting.getMeetingPeriods();
			Assistant[] assistantsById = meeting.getAssistants();
			System.out.println("Section: " + meeting.getSection());
			if(meeting.getRoom() == null) {
				System.out.println("Room: Not available");
			}
			else {
				System.out.println("Room: " + meeting.getRoom());
			}
			if(meeting.getMeetingPeriods() == null || meeting.getMeetingPeriods().length == 0) {
				System.out.print("Meetings: Not available");
			}
			else {
				System.out.print("Meetings: ");
				boolean firstFound = false;
				for(int j = 0; j < meetingPeriods.length; j++) {
					MeetingPeriod meetingPeriod = meetingPeriods[j];
					if(j == 0) {
						if(meetingPeriod.getDay() != null) {
							firstFound = true;
							if(meetingPeriod.getTime() != null) {
								String start = "";
								String end = "";
								if(meetingPeriod.getTime().getStart() != null) {
									start = meetingPeriod.getTime().getStart();
								}
								if(meetingPeriod.getTime().getEnd() != null) {
									end = meetingPeriod.getTime().getEnd();
								}
								System.out.print(meetingPeriod.getDay() + " " + start + "-" 
										+ end);
							}
							else {
								System.out.print(meetingPeriod.getDay());
							}
						}
					}
					else {
						if(meetingPeriod.getDay() != null) {
							if(meetingPeriod.getTime() != null) {
								String start = "";
								String end = "";
								if(meetingPeriod.getTime().getStart() != null) {
									start = meetingPeriod.getTime().getStart();
								}
								if(meetingPeriod.getTime().getEnd() != null) {
									end = meetingPeriod.getTime().getEnd();
								}
								
								if(firstFound == false) {
									firstFound = true;
									System.out.print(meetingPeriod.getDay() + " " + start + "-" 
											+ end);
								}
								else {
									System.out.print(", " + meetingPeriod.getDay() + " " + start + "-" 
											+ end);
								}

							}
							else {
								
								if(firstFound == false) {
									System.out.print(meetingPeriod.getDay());
								}
								else {
									System.out.print(", " + meetingPeriod.getDay());
								}
							}
						}
					}	
				}
			}
			if(assistantsById == null || assistantsById.length == 0) {
				System.out.println("\nAssistants: Not available");
				return;
			}
			StaffMember[] staffMembers = course.getStaffMembers();
			ArrayList<String> assistantsByName = new ArrayList<String>();
			for(int j = 0; j < assistantsById.length; j++) {
				for(int k = 0; k < staffMembers.length; k++) {
					if(assistantsById[j].getStaffMemberID().equals(staffMembers[k].getId())) {
						assistantsByName.add(staffMembers[k].getName().getFname() + " "
								+ staffMembers[k].getName().getLname());
					}
				}
			}
			System.out.print("\nAssistants: ");
			for(int j = 0; j < assistantsByName.size(); j++) {
				String assistantName = assistantsByName.get(j);
				if(j == assistantsByName.size() - 1) {
					System.out.print(assistantName);
				}
				else {
					System.out.print(assistantName + ",");
				}	
			}
			if(i == meetingType.size() - 1){
				System.out.print("\n");
			}
			else {
				System.out.print("\n\n");
			}
		}
	}
	

}
