
public class Course {
	
	private String number;
	private String term;
	private String year;
	private StaffMember[] staffMembers;
	private Meeting[] meetings;
	
	public String getNumber() {
		return number;
	}
	
	public void setNumber(String number) {
		this.number = number;
	}
	
	public String getTerm() {
		return term;
	}
	
	public void setTerm(String term) {
		this.term = term;
	}
	
	public String getYear() {
		return year;
	}
	
	public void setYear(String year) {
		this.year = year;
	}
	
	public StaffMember[] getStaffMembers() {
		return staffMembers;
	}
	
	public void setStaffMembers(StaffMember[] staffMembers) {
		this.staffMembers = staffMembers;
	}
	
	public Meeting[] getMeetings() {
		return meetings;
	}
	
	public void setMeetings(Meeting[] meetings) {
		this.meetings = meetings;
	}
	
}
