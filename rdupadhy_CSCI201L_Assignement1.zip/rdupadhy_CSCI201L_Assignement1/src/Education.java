
public class Education {
	
	private School[] schools;
	
	public School[] getSchools() {
		return schools;
	}

	public void setSchools(School[] schools) {
		this.schools = schools;
	}	
	
}

