
public class Assistant {

	private String staffMemberID;

	public String getStaffMemberID() {
		return staffMemberID;
	}

	public void setStaffMemberID(String staffMemberID) {
		this.staffMemberID = staffMemberID;
	}
	
}
